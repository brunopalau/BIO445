#############################################
###### Molecular Dynamics
# prepared by Jessy Duran Ramirez
# 20.12.22
#############################################


# R preparations ---------------------------------------------------------------------------------
# Remove current working environment, load packages and set your working directory 
rm(list = ls())

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("ChemmineR")


setwd("your path here")

# set seed for reproducibility
set.seed("Write a number here")

# Problem 1  Molecules in R -------------------------------------------------------------------------

## a) Load the information of tannin into R
## YOUR CODE HERE ##


## b) Your favorite molecule! 
## YOUR CODE HERE ##


# Problem 2: Exploring potential candidates for the next drug  ---------------------------------------------

## a) Read in and explore the data set: 
desc <-  ## YOUR CODE HERE ##

  
## b) desc_unique: randomly delete duplicated IDs
##random select 1 experiment for each Monomer
descUnique1 <- ## YOUR CODE HERE ##
  
## average multiple measurements
descUnique2 <- ## YOUR CODE HERE ##

# continue with your subset:
## YOUR CODE HERE ##
  
  
## c) Look at correlation between the features
## YOUR CODE HERE ##


## d) linear regression
## YOUR CODE HERE ##


## e) training and test set
## YOUR CODE HERE ##

## f) fit models
## YOUR CODE HERE ##

## g) variable importance
## YOUR CODE HERE ##


## h) model performance 
## YOUR CODE HERE ##


## i) test set performance
## YOUR CODE HERE ##


## j) interpretation





